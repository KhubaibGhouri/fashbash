"use strict";
var router_1 = require("@angular/router");
var home_component_1 = require("./components/home/home.component");
var follow_component_1 = require("./components/follow/follow.component");
var userprofile_component_1 = require("./components/userprofile/userprofile.component");
var otherprofile_component_1 = require("./components/otherprofile/otherprofile.component");
var feeds_component_1 = require("./components/feed/feeds.component");
exports.router = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: home_component_1.HomeComponent },
    { path: 'follow', component: follow_component_1.FollowComponent },
    { path: 'profile', component: userprofile_component_1.UserprofileComponent },
    { path: 'otheruser', component: otherprofile_component_1.OtherProfileComponent },
    { path: 'feeds', component: feeds_component_1.FeedsComponent }
];
exports.routes = router_1.RouterModule.forRoot(exports.router);
//# sourceMappingURL=app.router.js.map