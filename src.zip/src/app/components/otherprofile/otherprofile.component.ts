import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'otheruser',
  templateUrl: `otherprofile.component.html`,
})
export class OtherProfileComponent  {}
