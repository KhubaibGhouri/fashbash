import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'follow',
  templateUrl: `follow.component.html`,
})
export class FollowComponent  {}
