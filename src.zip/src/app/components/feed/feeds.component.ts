import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'feeds',
  templateUrl: `feeds.component.html`,
})
export class FeedsComponent  {}
