import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'navtwo',
  templateUrl: `navbar_two.component.html`,
})
export class Navbar_twoComponent  {}
