"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var Navbar_twoComponent = (function () {
    function Navbar_twoComponent() {
    }
    return Navbar_twoComponent;
}());
Navbar_twoComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'navtwo',
        templateUrl: "navbar_two.component.html",
    })
], Navbar_twoComponent);
exports.Navbar_twoComponent = Navbar_twoComponent;
//# sourceMappingURL=navbar_two.component.js.map