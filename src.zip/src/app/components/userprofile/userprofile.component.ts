import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'userprofile',
  templateUrl: `userprofile.component.html`,
})
export class UserprofileComponent  {}
